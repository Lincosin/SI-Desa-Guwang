{{--
    Header temaku (desain dari Stitch, data tetap dari OpenSID).
    Dipertahankan dari header Esensi: $desa, setting(), gambar_desa(), $teks_berjalan,
    menu_tema() (lewat main_menu & mobile_menu), dan tautan layanan mandiri / siteman.
--}}

<header class="relative lg:sticky lg:top-0 z-50 bg-surface shadow-[0_1px_8px_rgba(0,0,0,0.06)]">

    {{-- 1. Strip: tombol Aksesibilitas (membuka panel yang sama dengan tombol mengambang), mode gelap/terang, dan tombol darurat. Panel: commons/aksesibilitas --}}
    <div class="bg-inverse-surface text-inverse-on-surface py-1">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between font-label-md text-label-md">
            <div class="flex items-center gap-2">
                <span class="hidden sm:inline text-inverse-on-surface/80">Tampilan:</span>
                <div class="flex items-center gap-1">
                    <button id="a11y-buka" type="button" data-a11y-buka aria-haspopup="dialog" aria-controls="a11y-panel" aria-expanded="false" title="Alat Aksesibilitas" class="px-2 py-0.5 rounded bg-surface-container-highest/20 hover:bg-surface-container-highest/40 inline-flex items-center gap-1">
                        <span class="material-symbols-outlined text-[14px] align-middle" aria-hidden="true">accessibility_new</span>
                        <span class="hidden sm:inline">Aksesibilitas</span>
                    </button>
                    <button id="tema-toggle" type="button" title="Ganti mode gelap / terang" aria-label="Ganti mode gelap atau terang" aria-pressed="false" class="px-2 py-0.5 rounded bg-surface-container-highest/20 hover:bg-surface-container-highest/40 inline-flex items-center gap-1">
                        <span class="material-symbols-outlined text-[14px] align-middle" data-tema-ikon aria-hidden="true">dark_mode</span>
                        <span class="hidden sm:inline" data-tema-label>Mode Gelap</span>
                    </button>
                </div>
            </div>
            {{-- Ganti nomor darurat sesuai desamu --}}
            <a href="tel:112" class="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-md bg-error text-on-error font-body-bold text-label-md hover:bg-error-container hover:text-on-error-container transition-colors">
                <span class="material-symbols-outlined text-[14px]">emergency</span>
                <span>Darurat: 112</span>
            </a>
        </div>
    </div>

    {{-- 2. Baris identitas desa --}}
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
        <a href="{{ site_url('/') }}" class="flex items-center gap-3 min-w-0">
            <img src="{{ gambar_desa($desa['logo']) }}"
                alt="Logo {{ ucfirst(setting('sebutan_desa')) . ' ' . ucwords($desa['nama_desa']) }}"
                class="h-12 w-auto object-contain flex-shrink-0">
            <div class="flex flex-col min-w-0">
                <span class="font-headline-sm text-headline-sm text-primary tracking-tight truncate">
                    {{ ucfirst(setting('sebutan_desa')) }} {{ ucwords($desa['nama_desa']) }}
                </span>
                <span class="font-caption text-caption text-on-surface-variant font-medium truncate">
                    {{ ucfirst(setting('sebutan_kecamatan_singkat')) }} {{ ucwords($desa['nama_kecamatan']) }},
                    {{ ucfirst(setting('sebutan_kabupaten_singkat')) }} {{ ucwords($desa['nama_kabupaten']) }},
                    Prov. {{ ucwords($desa['nama_propinsi']) }}
                </span>
            </div>
        </a>

        <div class="flex items-center gap-2 flex-shrink-0">
            @if (setting('layanan_mandiri') == 1)
                <a href="{{ site_url('layanan-mandiri') }}"
                    class="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-on-primary font-label-lg text-label-lg hover:bg-primary-container transition-all shadow-sm">
                    <span class="material-symbols-outlined text-[18px]">verified_user</span>
                    <span>Layanan Mandiri</span>
                </a>
            @endif
            <a href="{{ site_url('siteman') }}" title="Login Admin"
                class="w-9 h-9 rounded-full bg-primary text-on-primary flex items-center justify-center shadow-sm hover:bg-primary-container transition-colors">
                <span class="material-symbols-outlined text-[18px]">person</span>
            </a>
        </div>
    </div>

    {{-- 3. Menu dinamis OpenSID (sementara masih gaya Esensi, kita rapikan di langkah berikutnya) --}}
    @include('theme::commons.main_menu')
    @include('theme::commons.mobile_menu')

    {{-- 4. Teks berjalan --}}
    @if ($teks_berjalan)
        <div class="bg-secondary-fixed text-on-secondary-fixed py-1.5 overflow-hidden">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-2">
                <span class="flex items-center gap-1 font-body-bold text-label-md px-2 py-0.5 rounded bg-secondary-container text-on-secondary-container flex-shrink-0">
                    <span class="material-symbols-outlined text-[14px]">campaign</span>
                    <span>Pengumuman</span>
                </span>
                <marquee onmouseover="this.stop();" onmouseout="this.start();" class="block w-full font-caption text-caption">
                    @foreach ($teks_berjalan as $marquee)
                        <span class="px-3">
                            {{ $marquee['teks'] }}
                            @if (trim($marquee['tautan']) && $marquee['judul_tautan'])
                                <a href="{{ $marquee['tautan'] }}" class="font-body-bold hover:underline">{{ $marquee['judul_tautan'] }}</a>
                            @endif
                        </span>
                    @endforeach
                </marquee>
            </div>
        </div>
    @endif
</header>

<script>
    (function () {
        var root = document.documentElement;
        function on(id, fn) {
            var el = document.getElementById(id);
            if (el) el.addEventListener('click', fn);
        }
        // ---- Mode gelap / terang ----
        var TEMA_KEY = 'temaku-tema';
        var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
        function pilihanTema() {
            try {
                var t = localStorage.getItem(TEMA_KEY);
                return (t === 'gelap' || t === 'terang') ? t : 'auto';
            } catch (e) { return 'auto'; }
        }
        function terapkanTema(pilihan, animasi) {
            var gelap = pilihan === 'gelap' || (pilihan === 'auto' && mq && mq.matches);
            if (animasi) {
                root.classList.add('tema-transisi');
                setTimeout(function () { root.classList.remove('tema-transisi'); }, 350);
            }
            root.classList.toggle('dark', gelap);
            root.setAttribute('data-tema', pilihan);
            var tombol = document.getElementById('tema-toggle');
            if (tombol) {
                tombol.setAttribute('aria-pressed', gelap ? 'true' : 'false');
                tombol.querySelector('[data-tema-ikon]').textContent = gelap ? 'light_mode' : 'dark_mode';
                tombol.querySelector('[data-tema-label]').textContent = gelap ? 'Mode Terang' : 'Mode Gelap';
            }
        }
        on('tema-toggle', function () {
            var baru = root.classList.contains('dark') ? 'terang' : 'gelap';
            try { localStorage.setItem(TEMA_KEY, baru); } catch (e) {}
            terapkanTema(baru, true);
        });
        // Warga belum memilih: ikuti perubahan pengaturan perangkat. Tab lain: ikuti pilihan terbaru.
        if (mq) {
            var ikuti = function () { if (pilihanTema() === 'auto') { terapkanTema('auto', true); } };
            if (mq.addEventListener) { mq.addEventListener('change', ikuti); } else if (mq.addListener) { mq.addListener(ikuti); }
        }
        window.addEventListener('storage', function (e) { if (e.key === TEMA_KEY) { terapkanTema(pilihanTema(), true); } });
        terapkanTema(pilihanTema(), false);

    })();
</script>
